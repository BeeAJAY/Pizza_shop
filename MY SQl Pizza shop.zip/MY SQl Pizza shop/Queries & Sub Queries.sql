use pizzashop;

#  Retrieve the total number of orders placed.

select count(order_id)as Total_orders from orders;


# Calculate the total revenue generated from pizza sales.

select 
round(sum(orders_details.quantity*pizzas.price),2) as total_revenue
from orders_details join pizzas
on pizzas.pizza_id = orders_details.pizza_id;


#  Identify the highest-priced pizza.
select pizzatype.name , pizzas.price  
from pizzatype join pizzas
on pizzatype.pizza_type_id = pizzas.pizza_type_id
order by pizzas.price desc limit 1;



#  Identify the most common pizza size ordered.

select pizzas.size,count(orders_details.order_details_id) as order_count
from pizzas join orders_details
on pizzas.pizza_id = orders_details.pizza_id
group by pizzas.size order by order_count desc;


#  List all pizzas with their ingredients:

SELECT PizzaType.name AS pizza_name, PizzaType.ingredients
FROM PizzaType ;



#  List the top 5 most ordered pizza types along with their quantities.
select pizzatype.name , sum(orders_details.quantity)
from pizzatype join pizzas
on pizzas.pizza_type_id = pizzatype.pizza_type_id
join orders_details
on orders_details.pizza_id = pizzas.pizza_id
group by pizzatype.name order by quantity desc limit 5;

#  Calculate average pizza price:

SELECT round(AVG(price),2) AS average_pizza_price 
FROM Pizzas;

#Count the total number of pizzas sold:

SELECT SUM(Orders_details.quantity) AS total_pizzas_sold 
FROM Orders_details ;



##### SUB QUERIES ####

## Find the most expensive pizza

SELECT pizzatype.name AS pizza_name, Pizzas.size, Pizzas.price
FROM Pizzas 
JOIN PizzaType  ON Pizzas.pizza_type_id = PizzaType.pizza_type_id
WHERE Pizzas.price = (SELECT MAX(price) FROM Pizzas);

## Find pizzas that are more expensive than the average pizza price.

SELECT pizzatype.name AS pizza_name, Pizzas.size, Pizzas.price
FROM Pizzas 
JOIN PizzaType ON Pizzas.pizza_type_id = pizzatype.pizza_type_id
WHERE Pizzas.price > (SELECT AVG(price) FROM Pizzas);
# Find pizzas that have been ordered in more than one order.
SELECT pizzatype.name AS pizza_name, Pizzas.size
FROM Pizzas 
JOIN PizzaType  ON Pizzas.pizza_type_id = pizzatype.pizza_type_id
WHERE Pizzas.pizza_id IN (
    SELECT pizza_id
    FROM Orders_details
    GROUP BY pizza_id
    HAVING COUNT(DISTINCT order_id) > 1
);

# Find the name of the pizza that was ordered the most.
SELECT pizzatype.name AS pizza_name FROM PizzaType 
WHERE PizzaType.pizza_type_id = (
    SELECT Pizzas.pizza_type_id
    FROM Pizzas 
    JOIN Orders_details  ON Pizzas.pizza_id = Orders_details.pizza_id
    GROUP BY Pizzas.pizza_type_id
    ORDER BY SUM(Orders_details.quantity) DESC LIMIT 1 );