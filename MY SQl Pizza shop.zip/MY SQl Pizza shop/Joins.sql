use pizzashop;
select*from pizzas;
select*from pizzatype;
select*from orders;
select*from orders_details;


# find the total quantity of each pizza category ordered.

SELECT pizzatype.category, 
       SUM(orders_details.quantity) AS quantity
FROM pizzatype JOIN pizzas 
    ON pizzatype.pizza_type_id = pizzas.pizza_type_id
JOIN orders_details 
    ON orders_details.pizza_id = pizzas.pizza_id
GROUP BY pizzatype.category
ORDER BY quantity DESC;

# List all pizzas with their corresponding ingredients and price.

SELECT Pizzatype.name AS pizza_name, Pizzas.size, Pizzas.price, Pizzatype.ingredients
FROM Pizzas
JOIN PizzaType ON Pizzas.pizza_type_id = PizzaType.pizza_type_id;

# List all orders with the total number of pizzas ordered and the order date.
SELECT Orders.order_id, Orders.order_date, SUM(Orders_details.quantity) AS total_pizzas
FROM Orders
JOIN Orders_details ON Orders.order_id = Orders_details.order_id
GROUP BY Orders.order_id, Orders.order_date;

# Find pizzas that were never ordered (LEFT JOIN).
SELECT Pizzas.pizza_id, Pizzatype.name AS pizza_name, Pizzas.size
FROM Pizzas 
LEFT JOIN Orders_details  ON Pizzas.pizza_id = Orders_details.pizza_id
JOIN PizzaType  ON Pizzas.pizza_type_id = PizzaType.pizza_type_id
WHERE Orders_details.pizza_id IS NULL;

# Find the total number of pizzas sold for each size (S, M, L).

SELECT Pizzas.size, SUM(Orders_details.quantity) AS total_sold
FROM Orders_details 
JOIN Pizzas  ON Orders_details.pizza_id = Pizzas.pizza_id
GROUP BY Pizzas.size;

#  Find the total quantity of 'The California Chicken Pizza' sold.
SELECT pizzatype.name AS pizza_name, SUM(Orders_details.quantity) AS total_sold
FROM Orders_details 
JOIN Pizzas  ON Orders_details.pizza_id = Pizzas.pizza_id
JOIN PizzaType  ON Pizzas.pizza_type_id = PizzaType.pizza_type_id
WHERE PizzaType.name = 'The California Chicken Pizza'
GROUP BY PizzaType.name;
